# Pasta do GOWA (a ligação com o WhatsApp)

Coloque aqui o executável do GOWA com o nome **`whatsapp.exe`** (Windows). Ele **não vem no zip** (é um programa de terceiros,
e e-mail e antivírus costumam barrar `.exe` dentro de zip).

1. Baixe em https://github.com/aldinokemal/go-whatsapp-web-multidevice/releases (a versão que o `scripts/gowa-start.ps1`
   foi conferido é a **9.6.0**; em versões mais novas alguma opção pode ter mudado de nome, e aí peça ao Claude Code para
   ajustar o script).
2. Extraia o executável e renomeie para `whatsapp.exe` dentro desta pasta.
3. No `.env.local`: `GOWA_URL=http://localhost:3300` e `GOWA_BASIC_AUTH=usuario:senha` (invente os dois).
4. `npm run gowa`, abra http://localhost:3300 e leia o QR code com o **chip dedicado** (WhatsApp > Aparelhos conectados).

Esta pasta (`gowa/`) guarda também a **sessão do WhatsApp** (`storages/`), que equivale a estar logado no número. Ela fica
no `.gitignore`: nunca suba, compartilhe nem mande esta pasta para ninguém.

Mac/Linux: baixe o binário da sua plataforma e rode `./whatsapp rest` com as mesmas opções que estão em
`scripts/gowa-start.ps1` (porta 3300, `--basic-auth`, `--webhook http://localhost:3000/api/webhooks/wa`, `--webhook-secret`).
